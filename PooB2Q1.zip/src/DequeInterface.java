public interface DequeInterface {
}
