import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BigPriorityQueueTest {

    /* =========================================================
     *  ADAPTE ICI : nom de la classe + constructeur(s)
     * ========================================================= */
    private <T> BigPriorityQueueInterface<T> newQueueNatural() {
        return new BigPriorityQueue<>(); // <-- change si ta classe s'appelle autrement
    }

    private <T> BigPriorityQueueInterface<T> newQueueWithComparator(Comparator<T> cmp) {
        return new BigPriorityQueue<>(cmp); // <-- change si besoin
    }

    /* =========================================================
     *  Helpers
     * ========================================================= */
    private static <T> List<T> drain(BigPriorityQueueInterface<T> q) {
        List<T> out = new ArrayList<>();
        while (!q.isEmpty()) out.add(q.poll());
        return out;
    }

    private static <T> void assertDrain(BigPriorityQueueInterface<T> q, List<T> expected) {
        assertEquals(expected, drain(q));
    }

    /* =========================================================
     *  Tests ordre naturel
     * ========================================================= */
    @Nested
    class NaturalOrdering {

        @Test
        void queueVide_etatInitial() {
            var q = newQueueNatural();
            assertTrue(q.isEmpty());
            assertEquals(0, q.size());

            // Si ton impl jette une exception au lieu de null, adapte :
            assertNull(q.peek());
            assertNull(q.poll());
        }

        @Test
        void offer_null_interdit() {
            var q = newQueueNatural();
            assertThrows(NullPointerException.class, () -> q.offer(null));
        }

        @Test
        void insertionSimple_devientTete() {
            var q = newQueueNatural();
            assertTrue(q.offer(10));
            assertEquals(10, q.peek());
            assertEquals(1, q.size());
            assertFalse(q.isEmpty());
        }

        @Test
        void siPlusPetitQueLaTete_ilCoupeDevant() {
            var q = newQueueNatural();
            q.offer(10);     // tête = 10
            q.offer(20);     // fin
            q.offer(5);      // 5 < 10 => coupe devant

            assertEquals(5, q.peek());
            assertDrain(q, List.of(5, 10, 20));
        }

        @Test
        void siEgalALaTete_ilVaALaFin() {
            var q = newQueueNatural();
            q.offer(10);
            q.offer(10); // pas plus petit => fin
            assertDrain(q, List.of(10, 10));
        }

        @Test
        void siPlusGrandQueLaTete_ilVaALaFin() {
            var q = newQueueNatural();
            q.offer(10);
            q.offer(30);
            q.offer(20); // 20 >= 10 => fin
            assertDrain(q, List.of(10, 30, 20));
        }

        @Test
        void plusieursCoupesDevant_enCascade() {
            var q = newQueueNatural();
            q.offer(50);   // [50]
            q.offer(60);   // [50,60]
            q.offer(40);   // coupe => [40,50,60]
            q.offer(30);   // coupe => [30,40,50,60]
            q.offer(35);   // fin  => [30,40,50,60,35]
            assertDrain(q, List.of(30, 40, 50, 60, 35));
        }

        @Test
        void poll_metAJourLaTete_etLaTaille() {
            var q = newQueueNatural();
            q.offer(10);
            q.offer(20);
            q.offer(5); // [5,10,20]

            assertEquals(3, q.size());
            assertEquals(5, q.poll());
            assertEquals(2, q.size());
            assertEquals(10, q.peek());

            assertEquals(10, q.poll());
            assertEquals(1, q.size());
            assertEquals(20, q.peek());

            assertEquals(20, q.poll());
            assertTrue(q.isEmpty());
            assertEquals(0, q.size());
            assertNull(q.peek());
            assertNull(q.poll());
        }

        @Test
        void alternanceAjoutsEtRetraits_suitLaRegle() {
            var q = newQueueNatural();

            q.offer(10);          // [10]
            q.offer(20);          // [10,20]
            assertEquals(10, q.poll());  // [20]

            q.offer(30);          // [20,30]
            q.offer(5);           // 5 < 20 => [5,20,30]
            q.offer(25);          // fin => [5,20,30,25]

            assertDrain(q, List.of(5, 20, 30, 25));
        }
    }

    /* =========================================================
     *  Tests avec Comparator
     * ========================================================= */
    @Nested
    class ComparatorOrdering {

        @Test
        void comparatorEstUtilisePourLaRegleDuCut() {
            // comparator inversé: l'ordre "naturel" est inversé
            // donc "plus petit" selon comparator = valeur plus GRANDE
            Comparator<Integer> reverse = (a, b) -> Integer.compare(b, a);

            var q = newQueueWithComparator(reverse);

            q.offer(10); // tête=10
            q.offer(5);  // selon reverse, 5 n'est pas "plus petit" que 10 => fin
            q.offer(20); // selon reverse, 20 est "plus petit" que 10 => coupe devant

            assertDrain(q, List.of(20, 10, 5));
        }

        @Test
        void nullInterdit_memeAvecComparator() {
            var q = newQueueWithComparator(Comparator.naturalOrder());
            assertThrows(NullPointerException.class, () -> q.offer(null));
        }
    }

    /* =========================================================
     *  Tests ClassCast (si ordre naturel)
     * ========================================================= */
    @Nested
    class ClassCast {

        @Test
        @SuppressWarnings({ "rawtypes", "unchecked" })
        void insertionObjetNonComparable_peutLeverClassCastException() {
            // Selon ton impl, ça peut planter dès le 1er offer() (si compare à null impossible),
            // ou au 2e offer() (quand il doit comparer avec la tête).
            BigPriorityQueueInterface raw = newQueueNatural();

            Object a = new Object();
            Object b = new Object();

            try {
                raw.offer(a);
                assertThrows(ClassCastException.class, () -> raw.offer(b));
            } catch (ClassCastException ex) {
                // ok aussi : certaines impl jettent dès le 1er insert
                assertTrue(true);
            }
        }
    }
}
